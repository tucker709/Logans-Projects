const express = require('express');
const session = require('express-session');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();



// Main UI
app.get("/", function(req, res){
    res.sendFile(path.join(__dirname, 'mainUI.html'))
});

// Middleware
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: false }));

// Return input as Tree

app.post("/", function(req, res){
  
  const string = req.body.input
  const toArray = string.split`,`.map(x=>+x)
    
    // node Class
    class Node {
        constructor(toArray, left = null, right = null){
            this.toArray = toArray;
            this.left = left;
            this.right = right;
        }
    }
    
    // Bst Class
    class BST {
      constructor(){
        this.root = null;
      }
      add(toArray){
        const node = this.root;
        if(node === null) {
            this.root = new Node(toArray);
            return;
            }else{
             const Tree = function(node){
                if(toArray < node.toArray) {
                 if(node.left === null){
                    node.left = new Node(toArray);
                    return;
                    }else if(node.left !== null){
                    return Tree(node.left);
                    }
                }else if (toArray > node.toArray){
                    if(node.right === null){
                        node.right = new Node(toArray);
                        return;
                    }else if(node.right !== null){
                        return Tree(node.right);
                    }
                   }else{
                       return null;
                   }
                };
                return Tree(node);
            }
        }
    }
    const bst = new BST();
    for(const element of toArray) {
        bst.add(element);
    }
});



app.listen(3000, function(req, res) {
    console.log("Server is listening on Port 3000")
});