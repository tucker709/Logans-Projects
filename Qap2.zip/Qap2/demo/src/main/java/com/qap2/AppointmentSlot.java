package com.qap2;

public class AppointmentSlot {
    
    private int SlotID;
    private String Location;
    private int date;
    private int startTime;
    private int endTime;
    private String bloodType;

    public AppointmentSlot(int SlotID, String Location, int date, int startTime, int endTime, String bloodType){
        
        this.SlotID = SlotID;
        this.Location = Location;
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
        this.bloodType = bloodType;

    }
    // Getters
    public int getSlotID(){
        return this.SlotID;
    }
    public String getLocation(){
        return this.Location;
    }
    public int getDate(){
        return this.date;
    }
    public int getStartTime(){
        return this.startTime;
    }
    public int getEndTime(){
        return this.endTime;
    }
    public String getBloodType(){
        return this.bloodType;
    }
    // Setters
    public void setSlotID(int id){
        this.SlotID = id;
    }
    public void setLocation(String Lc){
        this.Location = Lc;
    }
    public void setDate(int date){
        this.date = date;
    }
    public void setStartTime(int Stime){
        this.startTime = Stime;
    }
    public void setEndTime(int Etime){
        this.startTime = Etime;
    }
    public void setBloodType(String type){
        this.bloodType = type;
    }
}
