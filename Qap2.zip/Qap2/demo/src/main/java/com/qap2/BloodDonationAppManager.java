package com.qap2;

import com.qap2.Database;
import com.qap2.AppointmentSlot;
import com.qap2.DonationAppointment;
import com.qap2.BloodDonor;

import java.util.List;
 
public class BloodDonationAppManager {
    
    private Database database;

    public BloodDonationAppManager(Database database) {
        this.database = database;

    }

    public DonationAppointment bookAppointment(BloodDonor bloodDonor) throws InvalidDonationSchedulingException {
        
        DonationAppointment donationAppointment = null;

        BloodDonor BloodDonor = database.getDonor(DonorID);

        LocalDate today = LocalDate.now();
        LocalDate tooYoung = today.minus(18, ChronoUnit.YEARS);

        if (bloodDonor.getDateOfBirth().isBefore(tooYoung)){
            throw new InvalidDonationSchedulingException("Donor too Young");
        };

        List<AppointmentSlot> appointmentSlotList = database.getAppointmentSlots();

        for (AppointmentSlot appointmentSlot: appointmentSlotList){
        }

        return donationAppointment;
    }

}
