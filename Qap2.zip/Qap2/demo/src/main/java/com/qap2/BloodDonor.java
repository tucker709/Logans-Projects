package com.qap2;

public class BloodDonor {
    
    private int DonorID;
    private String firstName;
    private String lastName;
    private int DateOfBirth;
    private String bloodType;
    private int nextAppointment;
    private int lastDonationDate;


    public BloodDonor(int DonorID, String firstName, String lastName, int DateOfBirth, String bloodType, int nextAppointment, int lastDonationDate){
        
        this.DonorID = DonorID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.DateOfBirth = DateOfBirth;
        this.bloodType = bloodType;
        this.nextAppointment = nextAppointment;
        this.lastDonationDate = lastDonationDate;

    }
    // Getters
    public int getDonorID(){
        return this.DonorID;
    }
    public String getFirstName(){
        return this.firstName;
    }
    public String getLastName(){
        return this.lastName;
    }
    public int getDateOfBirth(){
        return this.DateOfBirth;
    }
    public String getBloodType(){
        return this.bloodType;
    }
    public int getNextApp(){
        return this.nextAppointment;
    }
    public int getLastDonationDate(){
        return this.lastDonationDate;
    }
    // Setters
    public void setDonorID(int id){
        this.DonorID = id;
    }
    public void setFirstName(String name){
        this.firstName = name;
    }
    public void setLastName(String Lastname){
        this.lastName = Lastname;
    }
    public void setDateOfBirth(int birth){
        this.DateOfBirth = birth;
    }
    public void setBloodType(String type){
        this.bloodType = type;
    }
    public void setNextApp(int nextapp){
        this.nextAppointment = nextapp;
    }
    public void setLastDonationDate(int date){
        this.lastDonationDate = date;
    }

}
