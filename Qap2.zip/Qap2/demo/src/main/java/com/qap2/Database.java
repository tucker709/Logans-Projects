package com.qap2;

import com.qap2.AppointmentSlot;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

public class Database {
    
    public List<AppointmentSlot> getAppointmentSlot(){
        
        ArrayList<AppointmentSlot> appointmeantSlots = new ArrayList<AppointmentSlot>();

        AppointmentSlot appointmentSlot = new AppointmentSlot();
        appointmentSlot.setSlotID(1);
        appointmentSlot.setLocation("1 Random St. st. johns NL");

        appointmentSlots.add(appointmentSlot);

        return appointmentSlots;
    }
    public BloodDonor getDonor(int id) {
        BloodDonor bloodDonor = new BloodDonor();

        bloodDonor.setDateOfBirth(LocalDate.of( 1988, Month.FEBRUARY, 11 ))

        return bloodDonor;
    }
}
