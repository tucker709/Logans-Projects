package com.qap2;

public class DonationAppointment {
    
    private int AppID;
    private int DateAndTime;
    private int AppDuration;
    private String Location;
    private String bloodType;
    private String firstTimeOrNo;
    private int DonorID;

    public DonationAppointment(int AppID, int DateAndTime, int AppDuration, String Location, String bloodType, String firstTimeOrNo, int DonorID){
        
        this.AppID = AppID;
        this.DateAndTime = DateAndTime;
        this.AppDuration = AppDuration;
        this.Location = Location;
        this.bloodType = bloodType;
        this.firstTimeOrNo = firstTimeOrNo;
        this.DonorID = DonorID;

    }
    // Getters
    public int getAppID(){
        return this.AppID;
    }
    public int getDateAndTime(){
        return this.DateAndTime;
    }
    public int getAppDuration(){
        return this.AppDuration;
    }
    public String getLocation(){
        return this.Location;
    }
    public String getBloodType(){
        return this.bloodType;
    }
    public String getFirstTimeOrNo(){
        return this.firstTimeOrNo;
    }
    public int getDonorID(){
        return this.DonorID;
    }
    // Setters
    public void setDonorID(int id){
        this.DonorID = id;
    }
    public void setAppID(int id){
        this.AppID = id;
    }
    public void setDateAndTime(int DandT){
        this.DateAndTime = DandT;
    }
    public void setAppDuration(int Duration){
        this.AppDuration = Duration;
    }
    public void setLocation(String Lc){
        this.Location = Lc;
    }

    public void setBloodType(String type){
        this.bloodType = type;
    }
    public void setFirstTimeOrNo(String firstTimeOrNot){
        this.firstTimeOrNo = firstTimeOrNot;
    }
}
