package com.qap2;

import java.time.LocalDate;
import java.time.Month;
import com.qap2.BloodDonor;
import com.qap2.Database;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Mock;
import org.junit.jupiter.api.Assertions;

public class DonationAppTest {

    @Mock

    private Database database;
    
    @Test
    public void testBloodDonorTooYoung() {
        
        BloodDonor BloodDonorTooYoung = new BloodDonor();
        BloodDonorTooYoung.setFirstName("logan");
        BloodDonorTooYoung.setLastName("tucker");
        BloodDonorTooYoung.setBloodType("A");
        BloodDonorTooYoung.setDateOfBirth(LocalDate.of(2008, Month.FEBRUARY, 11)); 
        BloodDonorTooYoung.setDonorID(1);
        
        
        when(database.getDonor(1)).thenReturn(
            BloodDonorTooYoung
        );
        
        BloodDonationAppManager bloodDonationAppManager = 
        new BloodDonationAppManager(database);

        try{
            DonationAppointment donationAppointment = bloodDonationAppManager.bookAppointment(1);
        } catch (InvalidDonationSchedulingException exception) {
            Assertions.assertTrue(exception.getMessage().equalsIgnoreCase("Donor too Young"));

        }

    }
}
