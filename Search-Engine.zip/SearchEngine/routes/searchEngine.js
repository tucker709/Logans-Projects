const express = require('express');
const router = express.Router();

const Pool = require('pg').Pool;
const pool = new Pool({
  user: 'me',
  host: 'localhost',
  database: 'finalSprint',
  password: 'Slasher3575',
  port: 5432,
});

const data = {
    message: 'Search the database',
    layout: 'layout.njk',
    title: 'Search',
    pages: global.pages
};


router.get('/', (req, res) => {
    res.render('searchEngine.njk', data)
});


module.exports = {
    router : router,
    pool : pool
};
