const bcrypt = require('bcrypt');
const express = require('express');
const router = express.Router();
const passport = require('passport');


const data = {
    message: 'Sign in to your account',
    layout: 'layout.njk',
    title: 'SignIn',
    pages: global.pages,
};

router.get('/', function(req, res) {
    res.render('signIn.njk', data);
});

router.post('/', passport.authenticate('local', {
  successRedirect: '/',
  failureRedirect: '/signIn'
}));

module.exports = router;