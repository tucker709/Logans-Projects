const bcrypt = require('bcrypt');
const express = require('express');
const router = express.Router();
const pool = require('./searchEngine.js').pool


const data = {
    message: 'Create an account',
    layout: 'layout.njk',
    title: 'SignUp',
    pages: global.pages
};

router.get('/', function(req, res) {
    res.render('signUp.njk', data);
});

router.post('/', async function(req, res) {
    const { name, city, school, password } = req.body;
    const encryptedPassword = await bcrypt.hash(password, 10);
    let results = await pool.query('SELECT * FROM users where name = $1', [name])
    if(results.rows.length > 0){
        res.send("error! there is already an account with this name")
        return;
    }else{
        let insert_result = await pool.query('INSERT INTO users (name, city, school, password) VALUES ($1, $2, $3, $4)', [name, city, school, encryptedPassword])
    }
    if(global.passwords === undefined){
        global.passwords = {};
    }
    global.passwords[name] = encryptedPassword;

    res.redirect("/")
});

module.exports = {
    router : router,
}