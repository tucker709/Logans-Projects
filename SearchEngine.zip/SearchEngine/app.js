// All needed to function properly
const express = require('express');
var mongodb = require('mongodb');
var MongoClient = require('mongodb').MongoClient;
var URL = "mongodb://localhost:27017/finalSprint";
const path = require('path');
var cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
var logger = require('morgan');
const nunjucks = require('nunjucks');
var app = express();
const passport = require('passport');
const initPassport = require('./passport-config');
const session = require('express-session');
const db = require('./routes/searchEngine');
const cors = require('cors');
port = 3000;

nunjucks.configure('views', {
    noCache: true,
    autoescape: true,
    express: app
});
MongoClient.connect(URL, function(err, db) {
    if (err) throw err;
    console.log("Database created!");
    db.close();
});
MongoClient.connect(URL, function(err, db) {
    if (err) throw err;
    var dbo = db.db("finalSprint");
    db.close()
});



async function getUserByName(name){
    results = await db.pool.query(`SELECT * FROM users WHERE name = $1`, [name])
    return results.rows[0];
};
async function getUserById(id){
    results2 = await db.pool.query(`SELECT * FROM users WHERE id = $1`, [id])
    return results2.rows[0];
};


initPassport(passport, getUserByName, getUserById);


// Routes
var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var signInRouter = require('./routes/signIn');
var signUpRouter = require('./routes/signUp').router;
var searchRouter = require('./routes/searchEngine').router;
var resultsRouter = require('./routes/results').router;


// MiddleWare
app.use('/random', () => {
    console.log("This is a middleware running.");
});

// connect to and specify your mongo db


// Check signed In and not signed In
const checkSignedIn = (req, res, next) => {
    if(req.isAuthenticated()) { // if they are signed in
        return next(); // proceed to next middleware
    }
    res.redirect('/signIn'); // else, redirect them to the sign in page
};
const checkNotSignedIn = (req, res, next) => {
    if(req.isAuthenticated()) { // if they are not signed in
      res.redirect('/'); // send them to the home page
    }
    next(); // else, allow them to visit any page
};


// Uses
app.use(cors());
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(session({
    secret: 'unsafe value',
    resave: false,
    saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());

app.use('/', indexRouter);
app.use('/users', checkSignedIn, usersRouter);
app.use('/searchEngine', checkSignedIn, searchRouter);
app.use('/results', checkSignedIn, resultsRouter);
app.use('/signIn', checkNotSignedIn, signInRouter);
app.use('/signUp', checkNotSignedIn, signUpRouter);



// Port
app.listen(port, function(req, res){
    console.log(`Listening on port ${port}`)
});