const express = require('express');
const router = express.Router();

global.pages = [
    { url: "/", title: "Home"},
    { url: "/users", title: "Users"},
    { url: "/signIn", title: "Sign In"},
    { url: "/signUp", title: "Sign Up"},
    { url: "/searchEngine", title: "Search"},
    { url: "/results", title: "Results"}
];

const data = {
    message: 'Welcome',
    layout: 'layout.njk',
    title: 'Sprint 3 Project 1',
    pages: global.pages,
    users: global.registeredUsers
};

/* GET Home Page. */
router.get('/', async function(req, res) {
    data.user = req.user ? req.user.name : data.user;
    res.render('index.njk', data);
});

module.exports = router;