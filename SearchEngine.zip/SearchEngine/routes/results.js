const bcrypt = require('bcrypt');
const express = require('express');
const router = express.Router();
const pool = require('./searchEngine.js').pool



const data = {
    message: 'Results from database',
    layout: 'layout.njk',
    title: 'Results',
    pages: global.pages
};




router.post('/', async function(req, res) {
    const VIN_input= req.body.VIN_input
    const selector = req.body.selector
    if(selector === 'psql'){
        pool.query(`SELECT * FROM Cars WHERE VIN LIKE $1`, ['%' + VIN_input + '%'], (error, results) => {
            if (error) {
                console.log('ERROR: Could not complete search.')
                throw error
            } else {
                results = JSON.stringify(results.rows)
                res.render('results.njk', {
                    results : results
                })
            }
        });
    }else if(selector === 'mongodb'){
        const VIN_input = req.body.VIN_input
        results = await db("finalSprint").collection("cars").find({VIN_input: new RegExp(VIN_input, 'i') }).toArray()
        results = JSON.stringify(results.rows)
        res.render('results.njk', {
            results : results
        })
    }else{
        const VIN_input = req.body.VIN_input
        results2 = await pool.query(`SELECT * FROM Cars WHERE VIN LIKE $1`, ['%' + VIN_input + '%']);
        results3 = await db("finalSprint").collection("cars").find({VIN_input: new RegExp(VIN_input, 'i') }).toArray()
        results_1 = results2.rows.concat(results3);
        results = JSON.stringify(results_1)
        res.render('results.njk', {
            results : results
        })
    }    
});




router.get('/', function(req, res) {
    res.render('results.njk', data);
});


module.exports = {
    router : router,
};