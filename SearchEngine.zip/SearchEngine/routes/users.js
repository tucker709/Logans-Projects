const express = require('express');
const router = express.Router();


const data = {
    message: 'Hello all users', 
    layout: 'layout.njk',
    title: 'Users',
    pages: global.pages
};

/* GET users listing */
router.get('/', function(req, res) {
    res.render('users.njk', data);
});

/* POST user creation */
router.post('/', function(req, res) {
    const { name, city, school } = req.body;

    global.registeredUsers.push({ name, city, school });

    res.render('users.njk', data);
});

module.exports = router;

